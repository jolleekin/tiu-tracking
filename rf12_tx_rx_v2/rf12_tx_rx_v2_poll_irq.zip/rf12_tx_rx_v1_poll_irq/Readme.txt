TIUTRACKING - RFM12's TxRx v.1 -------------------------------------------------------
Demo package for our capstone project -  TIU Tracking (PSU, Intel) - version 1.0
by Dung Dang Le - Email: zung.dang.le at gmail.com

This package demonstrates wireless communication on hobby frequency 
band (i.e 433MHz...) using RFM12B transceiver modules and ATMega328 uC.
Our purpose is testing these RFM12B module functions: transmit/receive/Analog-RSSI,
which could be considered applying for our project later.

There are two different approaches will be introduced:
    + polling, no checksum based on Benedikt's library (sketch: RX.pde, TX.pde)
	+ interrupt with checksum based on RF12 arduino library by Jeelabs (sketch: 
	  crypRecv.pde,crypSend.pde)
	
Notes: 
 - No collision avoidance is considered yet in this version
 - To get ARSSI output, you may have to manually solder on a wire to a resistor to 
   access this pad (see picture on schematic folder, location shown in red circle).
   (thanks to Stephen Eaton)
 - Schematic provided by Jeelabs, used for both transmiting receiving modules
 - Antennas required for best performance, Ideally at 433MHz ~ 17cm length
 - Yeah, I used arduino board to program the chips and monitor the serial outputs
 ------------------------------------------------------------------------------------
